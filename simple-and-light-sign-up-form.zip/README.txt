A Pen created at CodePen.io. You can find this one at https://codepen.io/dope/pen/ZQWBeL.

 I've not made a pen in a while. I miss making random forms... so I er... made one.

Happy holiday, yo!